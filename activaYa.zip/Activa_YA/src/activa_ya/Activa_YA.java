package activa_ya;

import activaya.BusinessLayer.Coordinates;
import activaya.BusinessLayer.MobilityTrain;

public class Activa_YA {

    public static void main(String[] args) {
        
    }
    
}
