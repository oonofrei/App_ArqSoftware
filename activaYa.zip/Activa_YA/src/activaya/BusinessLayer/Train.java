package activaya.BusinessLayer;

public class Train {
    private Integer id;
}
