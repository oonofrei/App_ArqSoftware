package activaya.BusinessLayer;
public enum Rank {
    Sedentario,
    EnForma,
    Atleta
}
