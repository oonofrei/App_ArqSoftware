package activaya.BusinessLayer;

public class ImitationTrain extends Train{
    
}
