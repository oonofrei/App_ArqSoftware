package activaya.BusinessLayer;

public class Coordinates {
    Float latitude;
    Float longitude;

    public Coordinates(Float latitude, Float longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }
    
    
}
