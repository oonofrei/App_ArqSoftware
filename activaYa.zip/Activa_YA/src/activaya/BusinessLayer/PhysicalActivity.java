package activaya.BusinessLayer;
public enum PhysicalActivity {
    Bajo,
    Medio,
    Alto
}
