package activaya.BusinessLayer;

public class User {
    private String name;
    private Integer age;
    private String genre;
    private Float height;
    private Float weight;
    private PhysicalActivity physicalActivity;
    private Rank rank;
    private Integer rankingPosition;
    private Integer totalPoints;
    
}
