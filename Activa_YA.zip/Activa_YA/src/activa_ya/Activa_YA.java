package activa_ya;

import People_Manager.DataAccessLayer.RepositoryUsers;
import activaya.BusinessLayer.Models.Coordinates;
import activaya.BusinessLayer.Models.MobilityTrain;
import activaya.BusinessLayer.Models.User;

public class Activa_YA {

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {                      
                RepositoryUsers repo = new RepositoryUsers();
                repo.Insert(new User("1", "Mike"));
                repo.Insert(new User("2", "Eduardo"));
                
                ServiceEmployees service = new ServiceEmployees(repo);
                
                DetailFrame detailView = new DetailFrame();
                DetailPresenter detailPresenter = new DetailPresenter(detailView, repo);
                
                NewFrame newView = new NewFrame();
                NewPresenter newPresenter = new NewPresenter(newView, service);

                ListFrame listView = new ListFrame();
                ListPresenter listPresenter = new ListPresenter(listView, repo);
                listPresenter.setDetailPresenter(detailPresenter);
                detailPresenter.setListPresenter(listPresenter);
                listPresenter.load();
                
                listPresenter.setNewPresenter(newPresenter);
                newPresenter.setListPresenter(listPresenter);
            }
        });
    }
    
}
