
package People_Manager.DataAccessLayer;

import activaya.BusinessLayer.Models.User;
import activaya.BusinessLayer.Services.IRepositoryUsers;
import java.util.ArrayList;

public class RepositoryUsers implements IRepositoryUsers {

    @Override
    public ArrayList<User> GetAll() {
        //todo
        return null;
    }

    @Override
    public User GetById(String id) {
        return null;
    }

    @Override
    public void Update(User user) {
    }

    @Override
    public void Insert(User user) {
    }
    
}
