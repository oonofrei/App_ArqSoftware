
package activaya.BusinessLayer.Services;

import activaya.BusinessLayer.Models.User;
import java.util.ArrayList;


public interface IRepositoryUsers {
    ArrayList<User> GetAll(); 
    User GetById(String id); 
    void Update(User user); 
    void Insert(User user);
}
