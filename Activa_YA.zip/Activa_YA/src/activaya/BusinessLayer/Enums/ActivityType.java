
package activaya.BusinessLayer.Enums;

public enum ActivityType {
    FuerzaSup,
    FuerzaInf,
    Flexibilidad
}
