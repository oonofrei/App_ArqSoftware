package activaya.BusinessLayer.Enums;
public enum Rank {
    Sedentario,
    EnForma,
    Atleta
}
