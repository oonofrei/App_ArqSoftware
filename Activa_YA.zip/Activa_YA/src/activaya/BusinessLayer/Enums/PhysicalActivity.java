package activaya.BusinessLayer.Enums;
public enum PhysicalActivity {
    Bajo,
    Medio,
    Alto
}
