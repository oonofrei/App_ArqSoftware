package activaya.BusinessLayer.Models;

public abstract class Train {
    private String id;
    private Integer punctuation;
    private String userId;
    
    public Train(String id, String userId){
        this.id = id;
        this.punctuation = 0;
        this.userId = userId;
    }
    
    // getters, setters
    public String getId() {
        return id;
    }

    public Integer getPunctuation() {
        return punctuation;
    }

    public void setPunctuation(Integer punctuation) {
        this.punctuation = punctuation;
    }

    public String getUserId() {
        return userId;
    }
    
    
    // metodos
    public abstract Integer calculatePunctuation();
}
