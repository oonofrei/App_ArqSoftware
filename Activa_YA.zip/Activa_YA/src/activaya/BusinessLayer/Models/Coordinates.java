package activaya.BusinessLayer.Models;

public class Coordinates {
    Float latitude;
    Float longitude;

    public Coordinates(Float latitude, Float longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }
    
    
}
