
package activaya.BusinessLayer.Models;

import activaya.BusinessLayer.Enums.ActivityType;

public class Activity {
    private Integer punctuacionAct;
    private String id;
    private ActivityType type;  //0 fuerza sup, 1 fuerza inf, 2 flexibilidad

    public Activity(String id, ActivityType type) {
        this.id = id;
        this.type = type;
    }

    public void setPunctuacionAct(Integer punctuacionAct) {
        this.punctuacionAct = (int)(Math.random() * 100) + 1;
    }

    public Integer getPunctuacionAct() {
        return punctuacionAct;
    }
    
    
    
    
    
}
