package activaya.BusinessLayer.Models;

import activaya.BusinessLayer.Enums.Rank;
import activaya.BusinessLayer.Enums.PhysicalActivity;

public class User {
    private String name;
    private Integer age;
    private String genre;
    private Float height;
    private Float weight;
    private PhysicalActivity physicalActivity;
    private Rank rank;
    private Integer rankingPosition;
    private Integer totalPoints;
    private boolean sedentario;
    private int streak;
    private double weekTimePhone;
    private double distanceTraveled;
    private int numTrainCompleted;
    private String id;
    

    public User(String id, String name){
        this.id = id;
        this.name = name;
        this.rankingPosition = 0;
        this.totalPoints = 0;
        this.streak = 0;
        this.distanceTraveled = 0;
        this.numTrainCompleted = 0;
        this.sedentario = true;
        this.weekTimePhone = 0;
        this.rank = Rank.Sedentario;
    }

    
    // getters, setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public Float getHeight() {
        return height;
    }

    public void setHeight(Float height) {
        this.height = height;
    }

    public Float getWeight() {
        return weight;
    }

    public void setWeight(Float weight) {
        this.weight = weight;
    }

    public PhysicalActivity getPhysicalActivity() {
        return physicalActivity;
    }

    public void setPhysicalActivity(PhysicalActivity physicalActivity) {
        this.physicalActivity = physicalActivity;
    }

    public Rank getRank() {
        return rank;
    }

    public void setRank(Rank rank) {
        this.rank = rank;
    }

    public Integer getRankingPosition() {
        return rankingPosition;
    }

    public void setRankingPosition(Integer rankingPosition) {
        this.rankingPosition = rankingPosition;
    }

    public Integer getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(Integer totalPoints) {
        this.totalPoints = totalPoints;
    }

    public boolean isSedentario() {
        return sedentario;
    }

    public void setSedentario(boolean sedentario) {
        this.sedentario = sedentario;
    }

    public int getStreak() {
        return streak;
    }

    public void setStreak(int streak) {
        this.streak = streak;
    }

    public double getWeekTimePhone() {
        return weekTimePhone;
    }

    public void setWeekTimePhone(double weekTimePhone) {
        this.weekTimePhone = weekTimePhone;
    }

    public double getDistanceTraveled() {
        return distanceTraveled;
    }

    public void setDistanceTraveled(double distanceTraveled) {
        this.distanceTraveled = distanceTraveled;
    }

    public int getNumTrainCompleted() {
        return numTrainCompleted;
    }

    public void setNumTrainCompleted(int numTrainCompleted) {
        this.numTrainCompleted = numTrainCompleted;
    }

    
    // metodos
    public void assingRank(){
        if (totalPoints > 500){
            rank = Rank.Atleta;
        } else if (totalPoints > 250){
            rank = Rank.EnForma;
        } else
            rank = Rank.Sedentario;
    }
    
    public void calculateTotalPoints(int newPoints){
        totalPoints = totalPoints + newPoints;
        assingRank();
    }
}
