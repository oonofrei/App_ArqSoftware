package activaya.BusinessLayer.Models;

import java.util.List;


public class ImitationTrain extends Train{
    
    private List<Activity> activity;
    private int type;    //0 fuerza sup, 1 fuerza inf, 2 flexibilidad
    
    public ImitationTrain(String id, String userId) {
        super(id, userId);
    }
    
    
    @Override
    public Integer calculatePunctuation(){
        Integer points = 0;
        for (Activity activ : activity) {
            points += activ.getPunctuacionAct();
        }
        return points;
    }
}
