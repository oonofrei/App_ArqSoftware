package activaya.BusinessLayer.Models;

public class MobilityTrain extends Train {
    
    private Integer timeSeconds;
    private Double distanceTravelled;
    private Double meanSpeed;
    private Integer score;
    private Coordinates startCoordinates;
    private Coordinates endCoordinates;

    public MobilityTrain(String id, String userId) {
        super(id, userId);
    }

    public Double calculate_distance (){
        return Math.sqrt(Math.pow((startCoordinates.latitude - endCoordinates.latitude), 2)
                + Math.pow((startCoordinates.longitude - endCoordinates.longitude), 2));
    }

    public void setStartCoordinates(Coordinates startCoordinates) {
        this.startCoordinates = startCoordinates;
    }

    public void setEndCoordinates(Coordinates endCoordinates) {
        this.endCoordinates = endCoordinates;
    }
    
    @Override
    public Integer calculatePunctuation(){
        Integer points = 0;
        return points;
    }
    
    
}
